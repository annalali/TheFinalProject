//
//  voice detection.swift
//  TapBar
//
//  Created by sarahAldosari on 21/02/1444 AH.
//

import UIKit

class voice_detection: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    


}
